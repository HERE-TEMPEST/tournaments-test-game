export * from './aws-s3-options-factory.interface';
