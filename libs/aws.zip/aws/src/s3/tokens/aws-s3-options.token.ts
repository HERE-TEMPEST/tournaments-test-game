export const AWS_S3_MODULE_TOKEN = Symbol.for('AWS_S3_MODULE_TOKEN');
