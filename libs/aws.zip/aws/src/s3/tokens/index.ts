export * from './aws-s3-options.token';
